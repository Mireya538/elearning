$(function() {
	$( ".btn-edit-rule" ).click(function() {
		// $( "li.item-a" ).parent().first();
		    alert($('.my_class').$(this).attr('name');); 
	});

});