<!DOCTYPE html>
<html>
<head>
	<title>Cursos</title>
</head>
<body>


	<ul>

	<?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		<li> <?php echo e($curso->nombre); ?> </li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	

	</ul>


</body>
</html>