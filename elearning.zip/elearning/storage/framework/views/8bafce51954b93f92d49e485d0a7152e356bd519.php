<?php $__env->startSection('nav'); ?>
    <?php if(!Auth::guest()): ?>
        <?php $__currentLoopData = $grant_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grant_rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <?php if($grant_rol->rol_id == 1): ?>
                <li class="active">
                    <a href="<?php echo e(route('login')); ?>" >
                        <i class="fa fa-cog"></i> Admin </a>
                </li>
            <?php endif; ?>
            <?php if($grant_rol->rol_id == 2): ?>
                <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-pencil-square-o"></i> Editor </a></li>
            <?php endif; ?>
            <?php if($grant_rol->rol_id == 3): ?>
                <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-cog"></i> Moderador </a></li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container container-form">
    <div class="row">
        <div class="col-md-12">
            <div class="col-md-1"></div>
            <div class="col-md-10"> 
            <?php if(!Auth::guest()): ?>
                <?php $__currentLoopData = $grant_roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grant_rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <?php if($grant_rol->rol_id == 1): ?>
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#home" id="crud-roles"> Roles </a></li>
                            <li><a data-toggle="tab" href="#menu1" id="crud-usuarios"> Usuarios </a></li>
                            <li><a data-toggle="tab" href="#menu2" id="crud-cursos"> Cursos </a></li>
                            <li><a data-toggle="tab" href="#menu3" id="crud-recursos"> Recursos </a></li>
                        </ul>
                        <div class="panel panel-default">
                            <div class="panel-body tab-content">
                                <div class="col-md-5">
                                	<h1> Listar Roles </h1>
                                    <table class="table table-responsive table-hover table-inverse">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Nombre</th>
                                                <th>Modificar</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <tr>
                                                <th scope="row"> <?php echo e($rol->id); ?> </th>
                                                <td> <?php echo e($rol->nombre); ?> </td>
                                                <td> <a href="role/<?php echo e($rol->id); ?>" class="btn btn-info btn-edit-rule"><i class="fa fa-pencil"></i></a> </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                        </tbody>
                                    </table>
                                </div>
                                <div class="col-md-5">
                                	<h2> Gestionar Roles </h2>
							        <hr>
                                	<h3> Agregar </h3>
                                	<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('insertRole')); ?>">
							            <?php echo e(csrf_field()); ?>


						                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						                    <label for="name" class="col-md-4 control-label">Nombre</label>

						                    <div class="col-md-6">
						                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

						                        <?php if($errors->has('name')): ?>
						                            <span class="help-block">
						                                <strong><?php echo e($errors->first('name')); ?></strong>
						                            </span>
						                        <?php endif; ?>
						                    </div>
						                </div>
						                <div class="form-group center">
                                    		<button type="submit" class="btn btn-success" id="role-add"><i class="fa fa-plus"></i> Agregar</button>
							            </div>
							        </form>
							        <hr>
                                	<h3> Actualizar </h3>
                                	<form class="form-horizontal" role="form" method="PUT" action="<?php echo e(url('updateRole')); ?>">
							            <?php echo e(csrf_field()); ?>


						                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						                    <label for="name" class="col-md-4 control-label">Nombre</label>

						                    <div class="col-md-6">
						                        <input type="hidden" class="form-control" name="id">
						                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

						                        <?php if($errors->has('name')): ?>
						                            <span class="help-block">
						                                <strong><?php echo e($errors->first('name')); ?></strong>
						                            </span>
						                        <?php endif; ?>
						                    </div>
						                </div>
						                <div class="form-group center">
                                    		<button type="submit" class="btn btn-primary" value="Submit"><i class="fa fa-floppy-o"></i> Actualizar </button>
							            </div>
							        </form>
							        <hr>
                                	<h3> Eliminar </h3>
                                	<form class="form-horizontal" role="form" method="DELETE" >
							            <?php echo e(csrf_field()); ?>


						                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
						                    <label for="name" class="col-md-4 control-label">Nombre</label>

						                    <div class="col-md-6">
						                        <input type="hidden" class="form-control" name="id">
						                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

						                        <?php if($errors->has('name')): ?>
						                            <span class="help-block">
						                                <strong><?php echo e($errors->first('name')); ?></strong>
						                            </span>
						                        <?php endif; ?>
						                    </div>
						                </div>
						                <div class="form-group center">
                                    		<button type="submit" class="btn btn-danger" value="Submit"><i class="fa fa-floppy-o"></i> Eliminar </button>
							            </div>
							        </form>
                                </div>
                            </div>

                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            <?php endif; ?>
            </div>
            <div class="col-md-1"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="js/crud.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>